package mk.ukim.finki.emt_lab1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmtLab1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
