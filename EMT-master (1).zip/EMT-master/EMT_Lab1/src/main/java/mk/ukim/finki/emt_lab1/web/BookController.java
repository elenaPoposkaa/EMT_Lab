package mk.ukim.finki.emt_lab1.web;

import mk.ukim.finki.emt_lab1.model.Book;
import mk.ukim.finki.emt_lab1.model.dto.BookDto;
import mk.ukim.finki.emt_lab1.service.AuthorService;
import mk.ukim.finki.emt_lab1.service.BookService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {
    private final BookService bookService;
    private final AuthorService authorService;

    public BookController(BookService bookService, AuthorService authorService) {
        this.bookService = bookService;
        this.authorService = authorService;
    }


    @GetMapping
    public List<Book>findAll(){
        return bookService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> findById(@PathVariable Long id) {
        return bookService.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PreAuthorize("hasRole('LIBRARIAN')")
    @PostMapping("/add")
    public ResponseEntity<Book> save(@RequestBody BookDto product) { //ke vratime HTTP status(200,500...) i podatoci vo odgovorot
        return bookService.save(product)
                //ako se e validno knigata se zacuvuva ako ne vrakja empty
                .map(ResponseEntity::ok)
                //vrakja 200 i info za novata kniga
                .orElseGet(() -> ResponseEntity.notFound().build());
                //vrakja 404
    }

    @PreAuthorize("hasRole('LIBRARIAN')")
    @PutMapping("/edit/{id}")
    public ResponseEntity<Book> update(@PathVariable Long id, @RequestBody BookDto bookDto) {
        return bookService.update(id, bookDto)
                .map(ResponseEntity::ok)
                //ako knigata postoi vo DB i e updated vrakja 200 i novoto info za knigata
                .orElseGet(() -> ResponseEntity.notFound().build());
                //ako update ne uspee vrakja 404
    }

    @PreAuthorize("hasRole('LIBRARIAN')")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (bookService.findById(id).isPresent()) {
            bookService.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PreAuthorize("hasRole('LIBRARIAN')")
    @PutMapping("/rent/{id}")
    public void markBookAsRented(@PathVariable Long id){
        bookService.markAsRented(id);
    }

}
