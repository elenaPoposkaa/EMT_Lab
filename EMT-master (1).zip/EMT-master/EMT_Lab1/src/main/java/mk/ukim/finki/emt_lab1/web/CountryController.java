package mk.ukim.finki.emt_lab1.web;

import mk.ukim.finki.emt_lab1.model.Author;
import mk.ukim.finki.emt_lab1.model.Country;
import mk.ukim.finki.emt_lab1.model.dto.AuthorDto;
import mk.ukim.finki.emt_lab1.service.CountryService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/countries")
public class CountryController {
    private final CountryService countryService;

    public CountryController(CountryService countryService) {
        this.countryService = countryService;
    }

    @GetMapping
    public List<Country> findAll(){
        return countryService.findAll();
    }


    @GetMapping("/{id}")
    public ResponseEntity<Country> findById(@PathVariable Long id) {
        return countryService.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PreAuthorize("hasRole('LIBRARIAN')")
    @PostMapping("/add")
    public Optional<Country> save(@RequestBody Country product) {
        return countryService.save(product);

    }


}
