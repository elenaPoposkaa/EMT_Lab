package mk.ukim.finki.emt_lab1.model;

public enum Category {
    NOVEL, THRILLER, HISTORY, FANTASY, BIOGRAPHY, CLASSICS, DRAMA;
}
