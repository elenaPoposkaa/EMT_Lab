package mk.ukim.finki.emt_lab1.config;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.emt_lab1.model.Author;
import mk.ukim.finki.emt_lab1.model.Book;
import mk.ukim.finki.emt_lab1.model.Category;
import mk.ukim.finki.emt_lab1.model.Country;
import mk.ukim.finki.emt_lab1.repository.AuthorRepository;
import mk.ukim.finki.emt_lab1.repository.BookRepository;
import mk.ukim.finki.emt_lab1.repository.CountryRepository;
import org.springframework.stereotype.Component;

@Component
public class Data {
    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;
    private final CountryRepository countryRepository;

    public Data(BookRepository bookRepository, AuthorRepository authorRepository, CountryRepository countryRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
        this.countryRepository = countryRepository;
    }

    @PostConstruct
    public void init() {
        Country usa = countryRepository.save(new Country("USA", "North America"));
        Country uk = countryRepository.save(new Country("UK", "Europe"));
        Country germany = countryRepository.save(new Country("Germany", "Europe"));
        Country france = countryRepository.save(new Country("France", "Europe"));
        Country japan = countryRepository.save(new Country("Japan", "Asia"));

        Author author1 = authorRepository.save(new Author("Stephen", "King", usa));
        Author author2 = authorRepository.save(new Author("J.K.", "Rowling", uk));
        Author author3 = authorRepository.save(new Author("Goethe", "Johann", germany));
        Author author4 = authorRepository.save(new Author("Victor", "Hugo", france));
        Author author5 = authorRepository.save(new Author("Haruki", "Murakami", japan));

        bookRepository.save(new Book("The Shining", Category.THRILLER, author1, 10));
        bookRepository.save(new Book("Harry Potter", Category.FANTASY, author2, 15));
        bookRepository.save(new Book("Faust", Category.CLASSICS, author3, 8));
        bookRepository.save(new Book("Les Misérables", Category.DRAMA, author4, 12));
        bookRepository.save(new Book("Norwegian Wood", Category.NOVEL, author5, 20));

    }


}
