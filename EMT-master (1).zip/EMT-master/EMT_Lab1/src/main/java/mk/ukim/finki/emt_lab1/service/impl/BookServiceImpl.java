package mk.ukim.finki.emt_lab1.service.impl;

import mk.ukim.finki.emt_lab1.model.Author;
import mk.ukim.finki.emt_lab1.model.Book;
import mk.ukim.finki.emt_lab1.model.Category;
import mk.ukim.finki.emt_lab1.model.dto.BookDto;
import mk.ukim.finki.emt_lab1.repository.AuthorRepository;
import mk.ukim.finki.emt_lab1.repository.BookRepository;
import mk.ukim.finki.emt_lab1.service.AuthorService;
import mk.ukim.finki.emt_lab1.service.BookService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {
    private final BookRepository bookRepository;
    private final AuthorRepository authorService;

    public BookServiceImpl(BookRepository bookRepository, AuthorRepository authorService) {
        this.bookRepository = bookRepository;
        this.authorService = authorService;
    }

    @Override
    public List<Book> findAll() {
        return bookRepository.findAll();
    }
    @Override
    public Optional<Book> findById(Long id) {
        return bookRepository.findById(id);
    }

    @Override
    public Optional<Book> save(BookDto bookDto) {
        if (bookDto.getAuthor() == null || bookDto.getCategory() == null) {
            return Optional.empty(); //proveruva dali ima validen avtor i kategorija inaku ne dozvoluva zacuvuvanje na invalid vrednosti
        }

        Optional<Author> authorOptional = authorService.findById(bookDto.getAuthor()); //go bara soodvetniot avtor vo DB

        if (authorOptional.isPresent()) {
            Book book = new Book(
                    bookDto.getName(),
                    Category.valueOf(bookDto.getCategory().toUpperCase()), // pretvara vo enumerated value
                    authorOptional.get(), //go zima avtorot kako celosen objekt od Author model
                    bookDto.getAvaliableCopies()
            );
            return Optional.of(bookRepository.save(book));
        }

        return Optional.empty(); // If author doesn't exist, return empty
    }
    //proveruvam dali avtorot postoi vo DB zatoa sto knigata ima foreign key do nego
    //ako avtorot ne postoi ne moze da vneseme nova kniga
    //koristime DTO za da ne  mu dozvolime na klientot direktno da menuva vo bazata na podatoci

    @Override
    public Optional<Book> update(Long id, BookDto book) {
        return bookRepository.findById(id)
                .map(existingBook->{ //pravi referenca do knigata koja sakame da ja menuvame
                    if(book.getName()!=null){
                        existingBook.setName(book.getName());
                    }
                    if(book.getAvaliableCopies()!=null){
                        existingBook.setAvaliableCopies(book.getAvaliableCopies());
                    }
                    if(book.getCategory()!=null){
                        existingBook.setCategory(Category.valueOf(book.getCategory().toUpperCase()));
                    }
                    if(book.getAuthor()!=null && authorService.findById(book.getAuthor()).isPresent()){
                        existingBook.setAuthor(authorService.findById(book.getAuthor()).get());
                    }
                    return bookRepository.save(existingBook);
                });
    }


    @Override
    public Optional<Book> markAsRented(Long id) {
        Optional<Book>book1 = bookRepository.findById(id);
        if(book1.isPresent() && book1.get().getAvaliableCopies()>0){
            Book rented = book1.get();
            rented.setAvaliableCopies(rented.getAvaliableCopies()-1);
            return Optional.of(bookRepository.save(rented));
        }
        throw new RuntimeException("Book not available for rent");
    }


    @Override
    public void deleteById(Long id) {
        bookRepository.deleteById(id);
    }
}
