package mk.ukim.finki.emt_lab1.model.dto;

import jakarta.persistence.criteria.CriteriaBuilder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BookDto {
    private String name;
    private Integer avaliableCopies;
    private Long author;
    private String category;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAvaliableCopies() {
        return avaliableCopies;
    }

    public void setAvaliableCopies(Integer avaliableCopies) {
        this.avaliableCopies = avaliableCopies;
    }

    public Long getAuthor() {
        return author;
    }

    public void setAuthor(Long author) {
        this.author = author;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public BookDto(String name, Integer avaliableCopies, Long author, String category) {
        this.name = name;
        this.avaliableCopies = avaliableCopies;
        this.author = author;
        this.category = category;
    }

}
